# 3rd Party Addons

Though we try to pack Logger full of features we can't do everything. The community has really grown around the product and have started to develop their own projects related around Logger.

This page will serve as a simple listing for such projects. To add your project to the list just update this page and make a pull request.



Name | URL | Description
--- | --- | ---
Template Generator | [github.com/alexnuijten/loggerutil](https://github.com/alexnuijten/loggerutil) | Generates logger code for prebuilt procedures. [Blog article](http://nuijten.blogspot.nl/2015/04/speed-up-development-with-logger.html).
